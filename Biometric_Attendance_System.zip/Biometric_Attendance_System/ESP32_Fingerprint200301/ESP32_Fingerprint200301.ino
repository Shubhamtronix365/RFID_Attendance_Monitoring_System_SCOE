#include <WiFi.h>
#include <HTTPClient.h>
#include <Adafruit_Fingerprint.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

// ================== WIFI SETTINGS ==================
const char* ssid = "SSID";
const char* password = "PASSWORD";

String URL = "http://10.201.46.18/biometricattendancev2/getdata.php";
String device_token = "70464f50c62a92cd";

// ================== OLED SETTINGS ==================
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);

// ================== FINGERPRINT SETTINGS ==================
HardwareSerial mySerial(2);
Adafruit_Fingerprint finger = Adafruit_Fingerprint(&mySerial);

// ================== SETUP ==================
void setup() {
  Serial.begin(115200);
  delay(1000);

  // Initialize OLED
  if(!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println("OLED not found");
    while (1);
  }

  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(WHITE);
  display.setCursor(10,20);
  display.println("Connecting WiFi...");
  display.display();

  // Connect WiFi
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("\nWiFi Connected");
  display.clearDisplay();
  display.setCursor(20,20);
  display.println("WiFi Connected");
  display.display();
  delay(2000);

  // Initialize fingerprint sensor
  mySerial.begin(57600, SERIAL_8N1, 16, 17); // RX=16 TX=17
  finger.begin(57600);

  if (finger.verifyPassword()) {
    Serial.println("Fingerprint sensor detected!");
  } else {
    Serial.println("Fingerprint sensor NOT detected!");
    display.clearDisplay();
    display.setCursor(10,20);
    display.println("Sensor Error!");
    display.display();
    while (1);
  }

  display.clearDisplay();
  display.setCursor(10,20);
  display.println("Place Finger");
  display.display();
}

// ================== MAIN LOOP ==================
void loop() {

  int id = getFingerprintID();

  if (id > 0) {

    Serial.print("Attendance Marked for ID: ");
    Serial.println(id);

    display.clearDisplay();
    display.setTextSize(2);
    display.setCursor(15,20);
    display.println("ACCESS OK");
    display.display();

    sendToServer(id);

    delay(2000);

    display.clearDisplay();
    display.setTextSize(1);
    display.setCursor(10,20);
    display.println("Place Finger");
    display.display();
  }

  delay(200);
}

// ================== FINGER SEARCH FUNCTION ==================
int getFingerprintID() {

  uint8_t p = finger.getImage();
  if (p != FINGERPRINT_OK) return -1;

  p = finger.image2Tz();
  if (p != FINGERPRINT_OK) return -1;

  p = finger.fingerFastSearch();

  if (p == FINGERPRINT_OK) {
    Serial.print("Found ID #");
    Serial.print(finger.fingerID);
    Serial.print(" Confidence: ");
    Serial.println(finger.confidence);
    return finger.fingerID;
  } 
  else if (p == FINGERPRINT_NOTFOUND) {

    display.clearDisplay();
    display.setTextSize(2);
    display.setCursor(10,20);
    display.println("INVALID");
    display.display();

    Serial.println("Fingerprint Not Found");
    delay(2000);

    display.clearDisplay();
    display.setTextSize(1);
    display.setCursor(10,20);
    display.println("Place Finger");
    display.display();

    return -1;
  }

  return -1;
}

// ================== SEND DATA TO SERVER ==================
void sendToServer(int fingerID) {

  if (WiFi.status() == WL_CONNECTED) {

    HTTPClient http;

    String postData = "FingerID=" + String(fingerID) + 
                      "&device_token=" + device_token;

    http.begin(URL);
    http.addHeader("Content-Type", "application/x-www-form-urlencoded");

    int httpResponseCode = http.POST(postData);

    Serial.print("HTTP Response Code: ");
    Serial.println(httpResponseCode);

    http.end();
  }
}